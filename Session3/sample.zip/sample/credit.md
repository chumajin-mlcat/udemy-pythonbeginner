## Credits / Acknowledgments

Some images in this repository are from [The Oxford-IIIT Pet Dataset](https://www.robots.ox.ac.uk/~vgg/data/pets/)
by the Visual Geometry Group, University of Oxford, and are licensed under 
[CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/).

- Original Data URL: [https://www.robots.ox.ac.uk/~vgg/data/pets/](https://www.robots.ox.ac.uk/~vgg/data/pets/)
- License: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)
- Modifications: (if you have cropped or edited the images, mention it here)
